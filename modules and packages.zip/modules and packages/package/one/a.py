def funcOne():
    print("Hello for server 1")