def funcTwo():
    print("Hello from server 2")