def log_message(message):
    print(f"LOG: {message}")