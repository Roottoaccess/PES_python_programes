def add_student(name, grade):
    print(f"Student {name} added to {grade} grade")