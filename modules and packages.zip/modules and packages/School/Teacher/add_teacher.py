def add_teacher(name, course):
    print(f"{name} will teach {course}")